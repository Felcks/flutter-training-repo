package com.capivara.bolao

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class BolaoApplicationTests {

	@Test
	fun contextLoads() {
	}

}
